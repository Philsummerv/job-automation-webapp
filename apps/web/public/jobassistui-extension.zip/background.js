"use strict";
(() => {
  // src/storage.ts
  var DEFAULTS = {
    activeRun: null,
    template: null,
    syncedTemplate: null,
    entitlement: null,
    pendingActivities: [],
    resume: null,
    jobQueue: null,
    autoBrowse: false,
    autoApply: null
  };
  async function getItem(key) {
    const data = await chrome.storage.local.get(key);
    return key in data ? data[key] : DEFAULTS[key];
  }
  async function setItem(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  async function removeItem(key) {
    await chrome.storage.local.remove(key);
  }
  async function updateItem(key, fn) {
    const next = fn(await getItem(key));
    await setItem(key, next);
    return next;
  }

  // src/state/machine.ts
  var MAX_EVENTS = 50;
  function isForActiveRun(state, runId) {
    return state != null && state.runId === runId;
  }
  function withStatus(state, status, note, at, patch = {}) {
    const event = { at, status, note };
    return {
      ...state,
      ...patch,
      status,
      events: [...state.events, event].slice(-MAX_EVENTS)
    };
  }
  function completionEffects(done) {
    const effects = [{ kind: "clear-run" }];
    if (done.job && (done.job.title || done.job.company)) {
      effects.push({ kind: "confirm-log", tabId: done.tabId, job: done.job });
    }
    return effects;
  }
  function noChange(state) {
    return { state, effects: [] };
  }
  function mergeJob(prev, next) {
    if (!next) return prev;
    if (!prev) return next;
    return {
      title: prev.title ?? next.title,
      company: prev.company ?? next.company,
      url: prev.url ?? next.url
    };
  }
  function reduce(state, action) {
    switch (action.type) {
      // ── Start a run ──────────────────────────────────────────────────────────
      // Replaces any existing run (single active run at a time). Broadcast a scan
      // to every frame; the frame that owns the form answers with scan-result and
      // thereby reveals its frameId.
      case "start-run": {
        const fresh = {
          runId: action.runId,
          tabId: action.tabId,
          status: "starting",
          pageIndex: 0,
          formFrameId: null,
          questions: [],
          reviewDecision: null,
          job: null,
          events: [{ at: action.at, status: "starting", note: "run created" }]
        };
        const scanning = withStatus(fresh, "scanning", "broadcast scan", action.at);
        const effects = [
          { kind: "send-command", tabId: action.tabId, command: "scan", runId: action.runId },
          { kind: "arm-no-form-timeout", tabId: action.tabId, runId: action.runId }
        ];
        return { state: scanning, effects };
      }
      // ── Job identity sighting ─────────────────────────────────────────────────
      // Accepted in ANY status: the page naming the employer is frequently one
      // with no form on it, so this can't be tied to the scan/fill cycle.
      case "job-meta": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        const merged = mergeJob(state.job, action.job);
        return { state: { ...state, job: merged }, effects: [] };
      }
      // ── Cancel ───────────────────────────────────────────────────────────────
      case "cancel-run": {
        if (state == null) return noChange(state);
        return { state: null, effects: [{ kind: "clear-run" }] };
      }
      // ── Scan result ──────────────────────────────────────────────────────────
      // Only meaningful while scanning. Empty result = no form on this page →
      // the flow is done (e.g. the post-submit confirmation page).
      case "scan-result": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "scanning") return noChange(state);
        const job = mergeJob(state.job, action.job);
        if (action.questions.length === 0) {
          const done = withStatus(state, "done", "no questions \u2014 flow complete", action.at, { job });
          return { state: done, effects: completionEffects(done) };
        }
        const filling = withStatus(
          state,
          "filling",
          `scanned ${action.questions.length} question(s)`,
          action.at,
          { formFrameId: action.frameId, questions: action.questions, job }
        );
        return {
          state: filling,
          effects: [
            { kind: "send-command", tabId: state.tabId, frameId: action.frameId, command: "fill", runId: state.runId }
          ]
        };
      }
      // ── Fill result ──────────────────────────────────────────────────────────
      // Fill done → open the review gate (M-B5 renders the actual UI). NEVER
      // auto-advances; we wait for a review-decision.
      case "fill-result": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "filling") return noChange(state);
        const review = withStatus(state, "review", "awaiting review", action.at, {
          reviewDecision: null
        });
        const effects = state.formFrameId != null ? [{ kind: "send-command", tabId: state.tabId, frameId: state.formFrameId, command: "review", runId: state.runId }] : [];
        return { state: review, effects };
      }
      // ── Review decision ──────────────────────────────────────────────────────
      case "review-decision": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "review") return noChange(state);
        if (action.decision === "rejected") {
          const done = withStatus(state, "done", "user rejected \u2014 run ended", action.at, {
            reviewDecision: "rejected"
          });
          return { state: done, effects: [{ kind: "clear-run" }] };
        }
        const advancing = withStatus(state, "advancing", `review ${action.decision} \u2014 advancing`, action.at, {
          reviewDecision: action.decision
        });
        const effects = state.formFrameId != null ? [{ kind: "send-command", tabId: state.tabId, frameId: state.formFrameId, command: "advance", runId: state.runId }] : [];
        return { state: advancing, effects };
      }
      // ── Pause / resume (user takes manual control) ────────────────────────────
      // Pause is allowed from any live, non-terminal status. The assist simply
      // stops issuing commands; the user edits the real page directly.
      case "pause-run": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status === "done" || state.status === "error" || state.status === "paused") {
          return noChange(state);
        }
        return { state: withStatus(state, "paused", "user paused \u2014 manual control", action.at), effects: [] };
      }
      // Resume re-opens the review gate on the current page so it reflects any
      // manual edits (the gate reads live form state). If we somehow have no
      // questions, fall back to a rescan.
      case "resume-run": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "paused") return noChange(state);
        if (state.questions.length > 0 && state.formFrameId != null) {
          const review = withStatus(state, "review", "resumed \u2014 re-review current page", action.at, {
            reviewDecision: null
          });
          return {
            state: review,
            effects: [{ kind: "send-command", tabId: state.tabId, frameId: state.formFrameId, command: "review", runId: state.runId }]
          };
        }
        const rescan = withStatus(state, "scanning", "resumed \u2014 rescanning", action.at, {
          formFrameId: null,
          questions: []
        });
        return {
          state: rescan,
          effects: [
            { kind: "send-command", tabId: state.tabId, command: "scan", runId: state.runId },
            { kind: "arm-no-form-timeout", tabId: state.tabId, runId: state.runId }
          ]
        };
      }
      // ── Navigation completed (from chrome.webNavigation, top frame) ───────────
      // Only advances the run when we were expecting it (status advancing). A nav
      // in any other status (user clicked around) is ignored so we don't rescan
      // spuriously.
      case "nav-completed": {
        if (state == null || state.tabId !== action.tabId) return noChange(state);
        if (state.status !== "advancing") return noChange(state);
        const nextPage = withStatus(state, "scanning", "next page loaded \u2014 rescanning", action.at, {
          pageIndex: state.pageIndex + 1,
          formFrameId: null,
          questions: [],
          reviewDecision: null
        });
        return {
          state: nextPage,
          effects: [
            { kind: "send-command", tabId: state.tabId, command: "scan", runId: state.runId },
            { kind: "arm-no-form-timeout", tabId: state.tabId, runId: state.runId }
          ]
        };
      }
      // ── Scan still in progress ────────────────────────────────────────────────
      // The scanning frame reports that it's stepping past a page that asks
      // nothing (commute-check, resume-selection). Each of those steps costs a
      // click plus a render, which easily outlasts the no-form window — and once
      // that fires the run is over, so the eventual scan-result is dropped and the
      // panel spins forever. Re-arm the window for every step the frame reports.
      case "scan-progress": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "scanning") return noChange(state);
        return {
          state,
          effects: [{ kind: "arm-no-form-timeout", tabId: state.tabId, runId: state.runId }]
        };
      }
      // ── No form found within the scan window ──────────────────────────────────
      // The controller's timeout fired without a scan-result. If we were still
      // scanning, treat the flow as complete (nothing left to fill).
      case "no-form": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        if (state.status !== "scanning") return noChange(state);
        const done = withStatus(state, "done", "no form frame responded \u2014 flow complete", action.at);
        return { state: done, effects: completionEffects(done) };
      }
      // ── Error ─────────────────────────────────────────────────────────────────
      case "run-error": {
        if (!isForActiveRun(state, action.runId)) return noChange(state);
        const errored = withStatus(state, "error", action.reason, action.at, { error: action.reason });
        return { state: errored, effects: [] };
      }
      default: {
        const _never = action;
        return noChange(state);
      }
    }
  }

  // src/background.ts
  var VERSION = chrome.runtime.getManifest().version;
  var NO_FORM_TIMEOUT_MS = 12e3;
  chrome.runtime.onInstalled.addListener(() => {
    console.log(`JobAssistUI installed (v${VERSION})`);
  });
  var chain = Promise.resolve();
  var runSeq = 0;
  function dispatch(makeAction) {
    chain = chain.then(async () => {
      try {
        const state = await getItem("activeRun");
        const action = makeAction(state);
        if (action == null) return;
        const result = reduce(state, action);
        if (result.state == null) {
          await removeItem("activeRun");
        } else {
          await setItem("activeRun", result.state);
        }
        for (const effect of result.effects) await runEffect(effect);
      } catch (err) {
        console.error("[JobAssistUI] dispatch failed", err);
      }
    });
    return chain;
  }
  function pressApplyInPage() {
    const matches = (el) => !!el && /apply with indeed/i.test(el.innerText || "");
    const wrapper = Array.from(
      document.querySelectorAll(
        '[class*="indeed-apply-status-not-applied"], [data-click-handler="attached"]'
      )
    ).find(matches);
    const button = wrapper?.querySelector("button") ?? Array.from(document.querySelectorAll("button")).find(
      (b) => /apply with indeed/i.test(b.innerText || "") || /apply with indeed/i.test(b.getAttribute("aria-label") || "")
    );
    const targets = [button, wrapper].filter(Boolean);
    if (!targets.length) return "not-found";
    const ev = () => new MouseEvent("click", { bubbles: true, cancelable: true, view: window });
    let calledHandler = false;
    for (const t of targets) {
      const handler = t.onclick;
      if (typeof handler === "function") {
        try {
          handler.call(t, ev());
          calledHandler = true;
        } catch {
        }
      }
    }
    (button ?? wrapper)?.click();
    return calledHandler ? "handler" : "click";
  }
  async function runEffect(effect) {
    switch (effect.kind) {
      case "send-command": {
        const msg = { type: "command", runId: effect.runId, command: effect.command };
        try {
          if (effect.frameId != null) {
            await chrome.tabs.sendMessage(effect.tabId, msg, { frameId: effect.frameId });
          } else {
            await chrome.tabs.sendMessage(effect.tabId, msg);
          }
        } catch {
        }
        return;
      }
      case "clear-run":
        await removeItem("activeRun");
        return;
      case "arm-no-form-timeout":
        armNoFormTimeout(effect.tabId, effect.runId);
        return;
      case "confirm-log": {
        const msg = { type: "confirm-log", job: effect.job };
        try {
          await chrome.tabs.sendMessage(effect.tabId, msg, { frameId: 0 });
        } catch {
        }
        return;
      }
    }
  }
  var noFormTimer = null;
  function armNoFormTimeout(_tabId, forRunId) {
    if (noFormTimer != null) clearTimeout(noFormTimer);
    noFormTimer = setTimeout(() => {
      noFormTimer = null;
      dispatch(() => ({ type: "no-form", runId: forRunId, at: Date.now() }));
    }, NO_FORM_TIMEOUT_MS);
  }
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    switch (msg?.type) {
      // Run-control messages → reducer actions. Each stamps `at` and, where the
      // sender identifies the frame, threads sender.frameId through.
      case "start-run": {
        const tabId = sender.tab?.id;
        if (tabId == null) {
          sendResponse({ ok: false, reason: "no-tab" });
          return false;
        }
        (async () => {
          const ent = await getItem("entitlement");
          if (!ent?.signedIn) return sendResponse({ ok: false, reason: "not-signed-in" });
          if (!ent.entitled) return sendResponse({ ok: false, reason: "not-entitled" });
          const id = `run-${tabId}-${Date.now()}-${runSeq++}`;
          await dispatch(() => ({ type: "start-run", tabId, runId: id, at: Date.now() }));
          sendResponse({ ok: true });
        })();
        return true;
      }
      case "auth-status":
        setItem("entitlement", {
          signedIn: msg.signedIn,
          entitled: msg.entitled,
          email: msg.email,
          checkedAt: Date.now()
        }).then(() => sendResponse({ ok: true }));
        return true;
      case "template-sync":
        setItem("syncedTemplate", msg.template).then(() => sendResponse({ ok: true }));
        return true;
      // The reducer guards each of these on runId + status, so the controller can
      // forward them directly — no stale-run filtering needed here.
      case "cancel-run":
        dispatch(() => ({ type: "cancel-run", at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "scan-result": {
        const frameId = sender.frameId ?? 0;
        const questions = msg.questions;
        const job = msg.job;
        dispatch(() => ({ type: "scan-result", runId: msg.runId, frameId, questions, job, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      }
      case "scan-progress":
        dispatch(() => ({ type: "scan-progress", runId: msg.runId, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "click-apply": {
        const tabId = sender.tab?.id;
        if (tabId == null) {
          sendResponse({ ok: false, how: "not-found" });
          return false;
        }
        chrome.scripting.executeScript({ target: { tabId }, world: "MAIN", func: pressApplyInPage }).then((results) => {
          const how = results?.[0]?.result;
          sendResponse({ ok: how != null && how !== "not-found", how: how ?? "not-found" });
        }).catch(() => sendResponse({ ok: false, how: "not-found" }));
        return true;
      }
      case "job-meta":
        dispatch(() => ({ type: "job-meta", runId: msg.runId, job: msg.job, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "fill-result":
        dispatch(() => ({ type: "fill-result", runId: msg.runId, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "review-decision":
        dispatch(() => ({ type: "review-decision", runId: msg.runId, decision: msg.decision, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "pause-run":
        dispatch(() => ({ type: "pause-run", runId: msg.runId, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "resume-run":
        dispatch(() => ({ type: "resume-run", runId: msg.runId, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      case "run-error":
        dispatch(() => ({ type: "run-error", runId: msg.runId, reason: msg.reason, at: Date.now() })).then(() => sendResponse({ ok: true }));
        return true;
      // ── Compliance activity log queue ─────────────────────────────────────────
      case "log-activity": {
        const activity = {
          id: crypto.randomUUID(),
          employer_name: msg.employer_name,
          job_title: msg.job_title,
          url: msg.url,
          date: todayISO()
        };
        updateItem("pendingActivities", (q) => [...q, activity]).then(() => sendResponse({ ok: true }));
        return true;
      }
      case "pending-activities":
        getItem("pendingActivities").then((activities) => sendResponse({ activities }));
        return true;
      case "activities-flushed":
        updateItem("pendingActivities", (q) => q.filter((a) => !msg.ids.includes(a.id))).then(() => sendResponse({ ok: true }));
        return true;
      default:
        return false;
    }
  });
  function todayISO() {
    const d = /* @__PURE__ */ new Date();
    const m = String(d.getMonth() + 1).padStart(2, "0");
    const day = String(d.getDate()).padStart(2, "0");
    return `${d.getFullYear()}-${m}-${day}`;
  }
  chrome.tabs.onRemoved.addListener((tabId) => {
    dispatch((state) => state != null && state.tabId === tabId ? { type: "cancel-run", at: Date.now() } : null);
  });
  function onNav(details) {
    if (details.frameId !== 0) return;
    dispatch(() => ({ type: "nav-completed", tabId: details.tabId, at: Date.now() }));
  }
  chrome.webNavigation.onCompleted.addListener(onNav);
  chrome.webNavigation.onHistoryStateUpdated.addListener(onNav);
})();
