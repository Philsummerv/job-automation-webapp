"use strict";
(() => {
  // src/messages.ts
  function sendToWorker(msg) {
    return chrome.runtime.sendMessage(msg);
  }

  // src/web-bridge.ts
  async function reportAuth() {
    try {
      const res = await fetch("/api/extension/session", {
        credentials: "same-origin",
        headers: { accept: "application/json" },
        cache: "no-store"
      });
      if (!res.ok) return;
      const data = await res.json();
      await sendToWorker({
        type: "auth-status",
        signedIn: !!data.signedIn,
        entitled: !!data.entitled,
        email: data.email ?? null
      });
    } catch {
    }
  }
  async function syncTemplate() {
    try {
      const res = await fetch("/api/extension/template", {
        credentials: "same-origin",
        headers: { accept: "application/json" },
        cache: "no-store"
      });
      if (!res.ok) return;
      const data = await res.json();
      await sendToWorker({ type: "template-sync", template: data.template ?? null });
    } catch {
    }
  }
  async function flushActivities() {
    try {
      const res = await sendToWorker({ type: "pending-activities" });
      const activities = res?.activities ?? [];
      if (!activities.length) return;
      const flushed = [];
      for (const a of activities) {
        try {
          const r = await fetch("/api/extension/activity", {
            method: "POST",
            credentials: "same-origin",
            headers: { "content-type": "application/json", accept: "application/json" },
            body: JSON.stringify({
              employer_name: a.employer_name,
              job_title: a.job_title,
              url: a.url,
              date: a.date
            })
          });
          if (r.ok) flushed.push(a.id);
        } catch {
        }
      }
      if (flushed.length) await sendToWorker({ type: "activities-flushed", ids: flushed });
    } catch {
    }
  }
  function refresh() {
    reportAuth();
    syncTemplate();
    flushActivities();
  }
  refresh();
  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") refresh();
  });
})();
