"use strict";
(() => {
  // ../../packages/automation/src/forms.ts
  function collectFormQuestions() {
    {
      const questions = [];
      const sigToIdx = /* @__PURE__ */ new Map();
      const labels = document.querySelectorAll("label");
      const idsToText = (idAttr) => {
        if (!idAttr) return "";
        return idAttr.split(/\s+/).map((id) => document.getElementById(id)?.innerText?.trim() || "").filter(Boolean).join(" ").trim();
      };
      const groupQuestionText = (startEl) => {
        let node = startEl;
        for (let depth = 0; depth < 6 && node; depth++) {
          if (node.tagName === "FIELDSET") {
            const legend = node.querySelector(":scope > legend");
            const t = legend?.innerText?.trim();
            if (t) return t;
          }
          const role = node.getAttribute("role");
          const ariaLabel = node.getAttribute("aria-label");
          if ((role === "group" || role === "radiogroup") && ariaLabel && ariaLabel.trim()) {
            return ariaLabel.trim();
          }
          const labelledby = node.getAttribute("aria-labelledby");
          if (labelledby) {
            const t = idsToText(labelledby);
            if (t) return t;
          }
          node = node.parentElement;
        }
        return "";
      };
      const isVisible = (el) => {
        if (!(el instanceof HTMLElement)) return false;
        const cv = el.checkVisibility;
        if (typeof cv === "function") {
          return cv.call(el, { checkOpacity: true, checkVisibilityCSS: true });
        }
        return el.offsetParent !== null;
      };
      let synthCounter = 0;
      const ensureId = (el) => {
        if (el.id) return el.id;
        let id;
        do {
          id = "aaui-opt-" + synthCounter++;
        } while (document.getElementById(id));
        el.id = id;
        return id;
      };
      for (const label of labels) {
        let text = label.innerText?.trim();
        if (!text) continue;
        if (label.closest("[data-aaui-ignore]")) continue;
        if (!isVisible(label)) continue;
        const forId = label.getAttribute("for");
        let input = forId ? document.getElementById(forId) : null;
        if (!input) input = label.querySelector("input, select, textarea");
        const fieldset = label.closest("fieldset") || label.parentElement;
        const radios = fieldset ? fieldset.querySelectorAll('input[type="radio"]') : [];
        const checkboxes = fieldset ? fieldset.querySelectorAll('input[type="checkbox"]') : [];
        let type = "unknown";
        let options = [];
        let inputId = null;
        let inputName = null;
        if (radios.length > 0) {
          type = "radio";
          inputName = radios[0].name;
          const gt = groupQuestionText(radios[0]);
          if (gt) text = gt;
          options = Array.from(radios).map((r) => {
            const radioLabel = r.labels?.[0]?.innerText?.trim() || r.closest("label")?.innerText?.trim() || r.value;
            return { label: radioLabel, value: r.value, id: ensureId(r) };
          });
        } else if (checkboxes.length > 0) {
          type = "checkbox";
          inputName = checkboxes[0].name;
          const gt = groupQuestionText(checkboxes[0]);
          if (gt) text = gt;
          options = Array.from(checkboxes).map((c) => {
            const cbLabel = c.labels?.[0]?.innerText?.trim() || c.closest("label")?.innerText?.trim() || c.value;
            return { label: cbLabel, value: c.value, id: ensureId(c) };
          });
        } else if (input) {
          if (input.tagName.toLowerCase() === "select") {
            type = "select";
            options = Array.from(input.options).map((o) => ({ label: o.text, value: o.value }));
          } else if (input.tagName.toLowerCase() === "textarea") {
            type = "textarea";
          } else {
            type = (input.type || "text").toLowerCase();
          }
          inputId = input.id || null;
          inputName = input.name || null;
        } else {
          continue;
        }
        const optSig = (type === "radio" || type === "checkbox") && options.length && options.every((o) => o.id) ? type + "|" + options.map((o) => o.id).sort().join(",") : "";
        if (optSig) {
          const existingIdx = sigToIdx.get(optSig);
          if (existingIdx !== void 0) {
            if (text.length > questions[existingIdx].text.length) questions[existingIdx].text = text;
            continue;
          }
        }
        const dupe = questions.find(
          (q) => q.inputId && q.inputId === inputId || q.inputName && q.inputName === inputName || q.text === text
        );
        if (dupe) continue;
        if (optSig) sigToIdx.set(optSig, questions.length);
        questions.push({ text, type, options, inputId, inputName });
      }
      const widgets = document.querySelectorAll('[role="combobox"], [role="listbox"]');
      for (const w of widgets) {
        if (w.closest('nav, header, [role="navigation"], [data-aaui-ignore]')) continue;
        if (!isVisible(w)) continue;
        const wText = idsToText(w.getAttribute("aria-labelledby")) || w.getAttribute("aria-label")?.trim() || "";
        if (!wText) continue;
        const inputId = w.id || null;
        const dupe = questions.find(
          (q) => q.inputId && q.inputId === inputId || q.text === wText
        );
        if (dupe) continue;
        let options = [];
        const popupId = w.getAttribute("aria-controls");
        const popup = popupId ? document.getElementById(popupId) : null;
        if (popup) {
          options = Array.from(
            popup.querySelectorAll('[role="option"], input[type="checkbox"], input[type="radio"]')
          ).map((o) => {
            const label = o.labels?.[0]?.innerText?.trim() || o.closest("label")?.innerText?.trim() || o.innerText?.trim() || o.getAttribute("aria-label")?.trim() || "";
            return { label, value: o.value || label, id: o.id || void 0 };
          }).filter((o) => o.label);
        }
        questions.push({ text: wText, type: "combobox", options, inputId, inputName: null });
      }
      const anchorOf = (q) => {
        if (q.inputId) return document.getElementById(q.inputId);
        if (q.inputName) return document.querySelector(`[name="${CSS.escape(q.inputName)}"]`);
        if (q.options[0]?.id) return document.getElementById(q.options[0].id);
        return null;
      };
      questions.sort((a, b) => {
        const ea = anchorOf(a);
        const eb = anchorOf(b);
        if (!ea || !eb) return 0;
        const pos = ea.compareDocumentPosition(eb);
        if (pos & Node.DOCUMENT_POSITION_FOLLOWING) return -1;
        if (pos & Node.DOCUMENT_POSITION_PRECEDING) return 1;
        return 0;
      });
      return questions;
    }
  }

  // ../../packages/automation/src/indeed-search.ts
  function buildIndeedSearchUrl(query, loc, start = 0) {
    const base = loc ? `https://www.indeed.com/jobs?q=${encodeURIComponent(query)}&l=${encodeURIComponent(loc)}` : `https://www.indeed.com/jobs?q=${encodeURIComponent(query)}`;
    return start > 0 ? `${base}&start=${start}` : base;
  }
  function collectIndeedJobs() {
    return Array.from(document.querySelectorAll('[class*="job_seen_beacon"]')).map((card) => {
      const title = card.querySelector('[class*="jobTitle"] a, [class*="jobTitle"] span')?.innerText?.trim() || "N/A";
      const company = card.querySelector('[data-testid="company-name"], [class*="companyName"]')?.innerText?.trim() || "N/A";
      const location2 = card.querySelector('[data-testid="text-location"], [class*="companyLocation"]')?.innerText?.trim() || "N/A";
      const snippet = card.querySelector('[class*="snippet"], .job-snippet')?.innerText?.trim() || "N/A";
      const payMatch = card.innerText.match(
        /(?:from\s+)?\$[\d,]+(?:\.\d{2})?(?:\s*(?:-|–|to)\s*\$?[\d,]+(?:\.\d{2})?)?(?:\s*(?:an?|per)\s+(?:hour|year|month|week)|\s*(?:hourly|annually|yearly))?/i
      );
      const pay = payMatch ? payMatch[0].trim() : null;
      const linkEl = card.querySelector('[class*="jobTitle"] a');
      const href = linkEl?.getAttribute("href") ?? null;
      const link = href ? new URL(href, "https://www.indeed.com").href : "N/A";
      const cardText = card.innerText.toLowerCase();
      const isIndeedApply = cardText.includes("easily apply") || cardText.includes("indeed apply");
      return { title, company, location: location2, pay, snippet, link, isIndeedApply };
    });
  }

  // ../../packages/automation/src/autofill.ts
  function makeAutoFillAnswer(config) {
    return function getAutoFillAnswer(questionText) {
      const lower = questionText.toLowerCase();
      if (lower.includes("day")) return `__RADIO:${config.preferredDay}`;
      if (lower.includes("time") && !lower.includes("time zone") && !lower.includes("timezone")) return `__RADIO:${config.preferredTime}`;
      if (lower.includes("first name") || lower.includes("given name") || lower.includes("firstname")) return config.firstName;
      if (lower.includes("last name") || lower.includes("family name") || lower.includes("surname") || lower.includes("lastname")) return config.lastName;
      if (lower.includes("full name") || lower === "name" || lower === "name *" || lower.includes("your name") || lower.includes("legal name")) return `${config.firstName} ${config.lastName}`.trim();
      if (lower.includes("phone") || lower.includes("mobile") || lower.includes("contact number") || lower.includes("telephone") || lower.includes("cell")) return config.phone;
      if (lower.includes("relocate") || lower.includes("relocation") || lower.includes("willing to relocate") || lower.includes("commute")) return `__RADIO:${config.willingToRelocate}`;
      if (lower.includes("zip") || lower.includes("postal") || lower.includes("location-fields")) return config.zipCode;
      if (lower.includes("city")) return config.city;
      if (lower.includes("address")) return "__SKIP__";
      const wantsNA = lower.includes("n/a");
      if (lower.includes("previously worked") || lower.includes("association with") || lower.includes("formerly employed") || lower.includes("previously employed") || lower.includes("ever been employed") || lower.includes("ever worked")) {
        return wantsNA ? "N/A" : "__RADIO:No";
      }
      if (lower.includes("referred you") || lower.includes("referral") || lower.includes("acquaintance") || lower.includes("relatives employed") || lower.includes("friends or relatives") || lower.includes("know anyone")) {
        return wantsNA ? "N/A" : "__RADIO:No";
      }
      if (lower.includes("authorized to work") || lower.includes("legal authorization") || lower.includes("legally authorized") || lower.includes("right to work") || lower.includes("eligibility to work") || lower.includes("eligible to work")) return `__RADIO:${config.authorizedToWork}`;
      if (lower.includes("sponsorship") || lower.includes("sponsor") || lower.includes("visa") || lower.includes("work permit") || lower.includes("immigration status") || lower.includes("h-1b") || lower.includes("h1b") || lower.includes("petition") && lower.includes("employment")) {
        return `__RADIO:${config.needsSponsorship}`;
      }
      if (lower.includes("citizen") || lower.includes("citizenship")) return `__RADIO:${config.usCitizen}`;
      if (lower.includes("veteran") || lower.includes("protected vet")) return `__RADIO:${config.veteranStatus}`;
      if (lower.includes("disability") || lower.includes("disabled")) return `__RADIO:${config.disabilityStatus}`;
      if (lower.includes("18 years") || lower.includes("18 or older") || lower.includes("at least 18")) return `__RADIO:${config.is18OrOlder}`;
      if (lower.includes("high school") || lower.includes("diploma") || lower.includes("ged")) return `__RADIO:${config.hasDiploma}`;
      if (lower.includes("highest level of education") || lower.includes("level of education") || lower.includes("education level")) return `__RADIO:${config.educationLevel}`;
      if (lower.includes("driving")) return `__RADIO:${config.drivingLicense}`;
      if (lower.includes("driver's license") || lower.includes("drivers license") || lower.includes("driver") && lower.includes("license")) return `__RADIO:${config.drivingLicense}`;
      if (lower.includes("currently located") || lower.includes("current location") || lower.includes("where are you located")) return config.city;
      if (lower.includes("salary") || lower.includes("pay expectation") || lower.includes("desired pay") || lower.includes("compensation") || lower.includes("expected pay")) return config.salary;
      if (lower.includes("how many years") || lower.includes("years") && lower.includes("experience") && !lower.includes("do you have")) return config.yearsExperience;
      if (lower.includes("time zone") || lower.includes("timezone")) return config.timeZone;
      if (lower.includes("linkedin")) return config.linkedin;
      const isPriorContext = lower.includes("previous") || lower.includes("prior") || lower.includes("last") || lower.includes("most recent") || lower.includes("recent") || lower.includes("former");
      if (isPriorContext) {
        if (lower.includes("title") || lower.includes("position") || lower.includes("role")) {
          return config.priorJobTitle || null;
        }
        if (lower.includes("employer") || lower.includes("company") || lower.includes("organization") || lower.includes("workplace")) {
          return config.priorJobCompany || null;
        }
        if (lower.includes("how long") || lower.includes("duration") || lower.includes("tenure") || lower.includes("years at") || lower.includes("time at")) {
          return config.priorJobDuration || null;
        }
      }
      return null;
    };
  }

  // ../../packages/automation/src/config.ts
  var DEFAULT_CONFIG = {
    searchQuery: '"Chemistry"',
    searchLocation: "",
    firstName: "",
    lastName: "",
    phone: "",
    zipCode: "",
    city: "",
    salary: "70000",
    yearsExperience: "4",
    educationLevel: "Bachelor of Science in Chemistry,Bachelor's,Bachelor,Bachelors,B.S.,BS,BA,B.A.",
    willingToRelocate: "Yes",
    preferredDay: "Monday",
    preferredTime: "Afternoon",
    linkedin: "",
    timeZone: "EST",
    priorJobTitle: "",
    priorJobCompany: "",
    priorJobDuration: "",
    authorizedToWork: "Yes",
    needsSponsorship: "No",
    usCitizen: "Yes",
    is18OrOlder: "Yes",
    hasDiploma: "Yes",
    drivingLicense: "Yes",
    veteranStatus: "not a protected veteran,no,i am not,decline",
    disabilityStatus: "don't have a disability,do not have a disability,no,i do not wish to answer,decline",
    resumePath: null,
    resumeFile: null,
    twoCaptchaApiKey: null,
    maxApplications: 1,
    exclusionTitleRegex: "\\b(teacher|instructor|faculty|professor)\\b"
  };

  // src/messages.ts
  function sendToWorker(msg) {
    return chrome.runtime.sendMessage(msg);
  }

  // src/storage.ts
  var DEFAULTS = {
    activeRun: null,
    template: null,
    syncedTemplate: null,
    entitlement: null,
    pendingActivities: [],
    resume: null,
    jobQueue: null,
    autoBrowse: false,
    autoApply: null
  };
  async function getItem(key) {
    const data = await chrome.storage.local.get(key);
    return key in data ? data[key] : DEFAULTS[key];
  }
  async function setItem(key, value) {
    await chrome.storage.local.set({ [key]: value });
  }
  function onChange(key, cb) {
    const listener = (changes, area) => {
      if (area === "local" && key in changes) {
        cb(changes[key].newValue);
      }
    };
    chrome.storage.onChanged.addListener(listener);
    return () => chrome.storage.onChanged.removeListener(listener);
  }

  // src/content.ts
  var extDead = false;
  function extAlive() {
    try {
      return !!chrome.runtime?.id;
    } catch {
      return false;
    }
  }
  function markExtDead() {
    if (extDead) return;
    extDead = true;
    try {
      const p = document.getElementById("aaui-panel");
      if (p) {
        const n = document.createElement("div");
        n.textContent = "\u26A0 Extension was updated \u2014 reload this page to reconnect.";
        n.style.cssText = "margin:6px 0;padding:6px;background:#7f1d1d;border-radius:6px;color:#fff";
        p.prepend(n);
      }
    } catch {
    }
  }
  function sendToWorker2(msg) {
    if (extDead || !extAlive()) {
      markExtDead();
      return Promise.resolve(null);
    }
    return sendToWorker(msg).catch((e) => {
      const m = e instanceof Error ? e.message : String(e);
      if (m.includes("context invalidated") || m.includes("Receiving end does not exist")) {
        markExtDead();
      }
      return null;
    });
  }
  var FORM_CONTROL_SEL = 'input[type="radio"], input[type="checkbox"], select, textarea, input[type="text"], input[type="number"], input[type="tel"], input[type="email"], [role="combobox"], [role="radiogroup"]';
  function isApplicationControl(el) {
    if (el.closest("[data-aaui-ignore]")) return false;
    if (el.closest('header, nav, [role="search"], [role="banner"], [role="navigation"]')) {
      return false;
    }
    const ident = `${el.id} ${el.name || ""}`.toLowerCase();
    if (/search|text-input-what|text-input-where/.test(ident)) return false;
    if (el.type === "search") return false;
    return true;
  }
  function isRealApplicationQuestion(q) {
    const t = (q.text || "").toLowerCase();
    if (/get email updates|email updates for the latest|create a job alert|job alerts?\b/.test(t)) {
      return false;
    }
    if (/receiving (calls|texts|messages) from employers/.test(t)) return false;
    return true;
  }
  function findApplicationControl() {
    return Array.from(document.querySelectorAll(FORM_CONTROL_SEL)).find(
      isApplicationControl
    ) ?? null;
  }
  function domSummary() {
    const n = (sel) => Array.from(document.querySelectorAll(sel)).filter(isApplicationControl).length;
    return `labels:${n("label")} radios:${n('input[type="radio"]')} checks:${n('input[type="checkbox"]')} fieldsets:${n("fieldset")} selects:${n("select")} text:${n('input[type="text"], textarea')} combos:${n('[role="combobox"]')} iframes:${n("iframe")}`;
  }
  function isApplyPage() {
    return location.hostname.includes("smartapply.") || /indeedapply|applystart|\/apply\b/i.test(location.pathname);
  }
  function hasApplyFrame() {
    return Array.from(document.querySelectorAll("iframe")).some((f) => {
      const src = f.getAttribute("src") || "";
      if (!/smartapply|indeedapply/i.test(src)) return false;
      if (/preload/i.test(src)) return false;
      return !f.hasAttribute("hidden");
    });
  }
  function isApplyContext() {
    return isApplyPage() || hasApplyFrame();
  }
  var isTop = window.self === window.top;
  var hasForm = !!document.querySelector("form, fieldset, [class*='application']");
  if (isTop || hasForm) init();
  function init() {
    let template = null;
    let usingSynced = false;
    let getAutoFillAnswer = makeAutoFillAnswer(DEFAULT_CONFIG);
    let questions = [];
    let currentCompany = null;
    async function loadTemplate() {
      const synced = await getItem("syncedTemplate");
      usingSynced = synced != null;
      template = synced ?? await getItem("template");
      getAutoFillAnswer = makeAutoFillAnswer(mergedConfig(template));
    }
    loadTemplate();
    if (isTop && /^\/jobs\b/.test(location.pathname)) {
      void (async () => {
        if (!await getItem("autoBrowse")) return;
        await setItem("autoBrowse", false);
        await loadTemplate();
        await waitFor(() => document.querySelector('[class*="job_seen_beacon"]'), 6e3);
        await findJobs();
      })();
    }
    function getAnswer(field) {
      const questionText = field.text;
      if (template?.rules?.length) {
        const q = questionText.toLowerCase();
        for (const r of template.rules) {
          const m = r.match.trim().toLowerCase();
          if (m && q.includes(m)) return r.answer;
        }
      }
      const referral = referralAnswer(field);
      if (referral !== null) return referral;
      return getAutoFillAnswer(questionText);
    }
    function referralAnswer(field) {
      const lower = field.text.toLowerCase();
      const isReferral = lower.includes("referred") || lower.includes("referral");
      const isRelative = lower.includes("acquaintance") || lower.includes("relative") || lower.includes("friends or family") || lower.includes("know anyone") || lower.includes("know someone");
      if (!isReferral && !isRelative) return null;
      const raw = (template?.config ?? {})[isReferral ? "referralCompanies" : "relativeCompanies"];
      const hit = matchContact(parseContacts(raw), currentCompany);
      if (!hit) return lower.includes("n/a") ? "N/A" : "__RADIO:No";
      if (field.type === "radio" || field.type === "checkbox" || field.type === "select" || field.type === "combobox") {
        return "__RADIO:Yes";
      }
      return hit.name || "Yes";
    }
    const panel = document.createElement("div");
    panel.id = "aaui-panel";
    panel.setAttribute("data-aaui-ignore", "1");
    panel.style.cssText = [
      "position:fixed",
      "top:12px",
      "right:12px",
      "z-index:2147483647",
      "width:340px",
      "max-height:80vh",
      "overflow:auto",
      "background:#0f172a",
      "color:#e2e8f0",
      "border-radius:10px",
      "font:12px/1.45 system-ui,sans-serif",
      "padding:10px",
      "box-shadow:0 8px 30px rgba(0,0,0,.45)"
    ].join(";");
    panel.innerHTML = `
    <div id="aaui-head" style="display:flex;justify-content:space-between;align-items:center;margin-bottom:8px;cursor:move;user-select:none">
      <strong style="font-size:13px">JobAssistUI</strong>
      <span style="display:flex;gap:8px;align-items:center">
        <button id="aaui-template" title="Edit answer template" style="border:0;background:transparent;color:#e2e8f0;cursor:pointer;font-size:14px;padding:0">\u2699 Template</button>
        <button id="aaui-resume" title="Choose the resume to attach on applications" style="border:0;background:transparent;color:#e2e8f0;cursor:pointer;font-size:14px;padding:0">\u{1F4C4} Resume</button>
        <span style="opacity:.6" title="Build this tab is running. If it doesn't match your latest build, reload the extension AND reload the page \u2014 reloading the extension alone leaves open tabs on the old content script.">${isTop ? "top" : "iframe"} \xB7 ${"19:28:33"}</span>
        <button id="aaui-min" title="Minimize" style="border:0;background:transparent;color:#e2e8f0;cursor:pointer;font-size:16px;line-height:1;padding:0 2px">\u2013</button>
      </span>
    </div>
    <div id="aaui-body">
    <div style="display:flex;gap:6px;margin-bottom:6px">
      <button id="aaui-find" style="flex:1;padding:12px 8px;font-size:14px;font-weight:600;border:0;border-radius:6px;background:#7c3aed;color:#fff;cursor:pointer">\u{1F50E} Find jobs</button>
    </div>
    <div style="display:flex;gap:6px;margin-bottom:8px">
      <button id="aaui-start" style="flex:1;padding:6px;font-size:11px;border:1px solid #334155;border-radius:6px;background:transparent;color:#cbd5e1;cursor:pointer">\u21BB Rescan page</button>
      <button id="aaui-cancel" style="flex:1;padding:6px;font-size:11px;border:1px solid #334155;border-radius:6px;background:transparent;color:#cbd5e1;cursor:pointer">Cancel run</button>
    </div>
    <div id="aaui-review"></div>
    <div id="aaui-log" style="margin-top:8px;border-top:1px solid #334155;padding-top:6px;opacity:.85"></div>
    </div>
  `;
    document.documentElement.appendChild(panel);
    const bodyEl = panel.querySelector("#aaui-body");
    const minBtn = panel.querySelector("#aaui-min");
    const MIN_KEY = "aaui.minimized";
    const setMinimized = (min) => {
      bodyEl.style.display = min ? "none" : "";
      panel.style.width = min ? "auto" : "340px";
      panel.style.maxHeight = min ? "none" : "80vh";
      panel.style.overflow = min ? "visible" : "auto";
      minBtn.textContent = min ? "+" : "\u2013";
      minBtn.title = min ? "Expand" : "Minimize";
      try {
        sessionStorage.setItem(MIN_KEY, min ? "1" : "0");
      } catch {
      }
    };
    minBtn.addEventListener(
      "click",
      () => setMinimized(bodyEl.style.display !== "none")
    );
    try {
      if (sessionStorage.getItem(MIN_KEY) === "1") setMinimized(true);
    } catch {
    }
    const headEl = panel.querySelector("#aaui-head");
    const POS_KEY = "aaui.pos";
    const placeAt = (left, top) => {
      const maxLeft = Math.max(0, window.innerWidth - panel.offsetWidth);
      const maxTop = Math.max(0, window.innerHeight - 40);
      const l = Math.min(Math.max(0, left), maxLeft);
      const t = Math.min(Math.max(0, top), maxTop);
      panel.style.left = `${l}px`;
      panel.style.top = `${t}px`;
      panel.style.right = "auto";
      try {
        sessionStorage.setItem(POS_KEY, JSON.stringify({ l, t }));
      } catch {
      }
    };
    let dragOffX = 0;
    let dragOffY = 0;
    const onDragMove = (e) => {
      e.preventDefault();
      placeAt(e.clientX - dragOffX, e.clientY - dragOffY);
    };
    const onDragEnd = () => {
      document.removeEventListener("mousemove", onDragMove);
      document.removeEventListener("mouseup", onDragEnd);
    };
    headEl.addEventListener("mousedown", (e) => {
      if (e.target.closest("button")) return;
      const r = panel.getBoundingClientRect();
      dragOffX = e.clientX - r.left;
      dragOffY = e.clientY - r.top;
      document.addEventListener("mousemove", onDragMove);
      document.addEventListener("mouseup", onDragEnd);
      e.preventDefault();
    });
    try {
      const saved = sessionStorage.getItem(POS_KEY);
      if (saved) {
        const { l, t } = JSON.parse(saved);
        placeAt(l, t);
      }
    } catch {
    }
    window.addEventListener("resize", () => {
      if (panel.style.left) placeAt(parseInt(panel.style.left, 10), parseInt(panel.style.top, 10));
    });
    const logEl = panel.querySelector("#aaui-log");
    const reviewEl = panel.querySelector("#aaui-review");
    const log = (msg, ok) => {
      const line = document.createElement("div");
      line.textContent = (ok === void 0 ? "\xB7 " : ok ? "\u2713 " : "\u2717 ") + msg;
      if (ok === false) line.style.color = "#f87171";
      if (ok === true) line.style.color = "#4ade80";
      logEl.prepend(line);
    };
    function scanPage() {
      questions = collectFormQuestions();
      log(`scanned: ${questions.length} question(s)`);
      return questions;
    }
    async function scanWhenReady() {
      const hadControls = !!await waitFor(() => findApplicationControl(), 2500);
      if (!hadControls) {
        questions = [];
        log("scanned: 0 question(s) \u2014 no form controls on this page");
        return { found: [], hadControls: false };
      }
      const found = await waitFor(() => {
        const qs = collectFormQuestions().filter(isRealApplicationQuestion);
        return qs.length ? qs : null;
      }, 6e3, 250);
      questions = found ?? [];
      log(found ? `scanned: ${found.length} question(s)` : `scanned: 0 question(s) \u2014 ${domSummary()}`);
      return { found: questions, hadControls: true };
    }
    async function fillPage() {
      const run = await getItem("activeRun");
      currentCompany = run?.job?.company ?? captureJobMeta().company;
      for (const q of questions) {
        const auto = getAnswer(q);
        if (!auto || auto === "__SKIP__") continue;
        const result = await fillFieldDom(q, auto);
        log(`${q.text.slice(0, 40)} \u2192 ${result.detail}`, result.ok);
        await sleep(200);
      }
      const resume = await getItem("resume");
      if (resume) {
        const r = await attachResumeDom(resume);
        if (r) log(`resume \u2192 ${r.detail}`, r.ok);
      }
      log("fill pass done");
    }
    let busyTimer = null;
    function showBusy(text) {
      stopBusy();
      reviewEl.innerHTML = "";
      const box = mkEl(
        "div",
        "margin:6px 0;padding:14px;background:#1e293b;border-radius:6px;font-size:14px;font-weight:600;text-align:center"
      );
      reviewEl.appendChild(box);
      let n = 0;
      const paint = () => {
        box.textContent = `${text}${".".repeat(n++ % 4)}`;
      };
      paint();
      busyTimer = setInterval(paint, 400);
    }
    function stopBusy() {
      if (busyTimer) {
        clearInterval(busyTimer);
        busyTimer = null;
      }
    }
    function hideBusy() {
      stopBusy();
      reviewEl.innerHTML = "";
    }
    function renderStartConfirm(job) {
      reviewEl.innerHTML = "";
      reviewEl.appendChild(hHeader(
        "Ready when you are",
        "Nothing has been filled in or clicked yet."
      ));
      const card = mkEl(
        "div",
        "margin:6px 0;padding:12px;background:#1e293b;border-radius:6px;display:flex;flex-direction:column;gap:4px"
      );
      card.appendChild(mkEl("div", "font-weight:700;font-size:15px;line-height:1.3", job.title || "This application"));
      if (job.company) card.appendChild(mkEl("div", "font-size:13px;opacity:.9", job.company));
      reviewEl.appendChild(card);
      const row = mkEl("div", "display:flex;flex-direction:column;gap:6px;margin-top:6px");
      row.appendChild(makePrimary(mkBtn("Fill this application", "#059669", () => {
        log("starting \u2014 you confirmed this one");
        void startRun();
      })));
      row.appendChild(makePrimary(mkBtn("Not this one \u2014 go back", "#475569", () => {
        hideBusy();
        log("skipped \u2014 nothing was filled in");
        history.back();
      })));
      reviewEl.appendChild(row);
    }
    function failBusy(message) {
      stopBusy();
      reviewEl.innerHTML = "";
      const box = mkEl(
        "div",
        "margin:6px 0;padding:10px;background:#7f1d1d;border-radius:6px;font-size:12px;line-height:1.45",
        message
      );
      reviewEl.appendChild(box);
      log(message, false);
    }
    onChange("activeRun", (run) => {
      if (run && run.status !== "done" && run.status !== "error") return;
      if (!busyTimer) return;
      if (run?.status === "error") {
        failBusy(run.error ?? "The assist stopped with an error.");
        return;
      }
      stopBusy();
      reviewEl.innerHTML = "";
      reviewEl.appendChild(mkEl(
        "div",
        "margin:6px 0;padding:10px;background:#1e293b;border-radius:6px;font-size:12px;line-height:1.45",
        "Nothing left for the assist to fill here. Press \u201C\u21BB Rescan page\u201D to try again once the next step loads."
      ));
    });
    async function findJobs() {
      const cfg = template?.config ?? {};
      const query = (cfg.searchQuery ?? "").trim();
      const loc = (cfg.searchLocation ?? "").trim();
      if (!/^\/jobs\b/.test(location.pathname)) {
        if (!query) {
          log(
            template ? "add \u201CSearch: job title\u201D to your template first" : "open jobassistui.com in a tab (or reload it) to sync your template",
            false
          );
          return;
        }
        await setItem("autoBrowse", true);
        window.location.assign(buildIndeedSearchUrl(query, loc));
        return;
      }
      const saved = await getItem("jobQueue");
      const sameSearch = saved != null && saved.query === query && saved.location === loc;
      const seen = sameSearch && Array.isArray(saved.seen) ? saved.seen : [];
      const jobs = scrapeFilteredJobs();
      const firstUnseen = jobs.findIndex((j) => !seen.includes(j.link));
      const queue = {
        query,
        location: loc,
        start: currentStart(),
        cursor: firstUnseen >= 0 ? firstUnseen : jobs.length,
        seen,
        jobs
      };
      await setItem("jobQueue", queue);
      renderJobBrowser(queue);
    }
    function currentStart() {
      return parseInt(new URLSearchParams(location.search).get("start") ?? "0", 10) || 0;
    }
    function scrapeFilteredJobs() {
      const cfg = template?.config ?? {};
      let jobs = collectIndeedJobs().filter((j) => j.link !== "N/A");
      const scraped = jobs.length;
      const pattern = (cfg.exclusionTitleRegex ?? "").trim();
      if (pattern) {
        try {
          const re = new RegExp(pattern, "i");
          jobs = jobs.filter((j) => !re.test(j.title));
        } catch {
          log("\u201CSkip titles matching\u201D isn't a valid pattern \u2014 ignoring it", false);
        }
      }
      jobs.sort((a, b) => Number(b.isIndeedApply) - Number(a.isIndeedApply));
      const dropped = scraped - jobs.length;
      log(`found ${scraped} listing(s)${dropped > 0 ? `, skipped ${dropped} by title` : ""}`);
      return jobs;
    }
    function renderJobBrowser(queue) {
      reviewEl.innerHTML = "";
      if (!Array.isArray(queue.jobs)) queue = { ...queue, jobs: [] };
      if (!Array.isArray(queue.seen)) queue = { ...queue, seen: [] };
      if (!queue.jobs.length) {
        reviewEl.appendChild(hHeader(
          "No jobs found",
          "Nothing scraped from this results page \u2014 it may still be loading, or everything was filtered out by \u201CSkip titles matching\u201D."
        ));
        return;
      }
      const goNextPage = async () => {
        await setItem("jobQueue", { ...queue, start: queue.start + 10 });
        window.location.assign(buildIndeedSearchUrl(queue.query, queue.location, queue.start + 10));
      };
      const job = queue.jobs[queue.cursor];
      if (!job) {
        reviewEl.appendChild(hHeader(
          "That's all on this page",
          `You've been through all ${queue.jobs.length}.`
        ));
        reviewEl.appendChild(makePrimary(mkBtn("Next page of results \u2192", "#2563eb", goNextPage)));
        return;
      }
      reviewEl.appendChild(hHeader(
        `Job ${queue.cursor + 1} of ${queue.jobs.length}`,
        job.isIndeedApply ? "Easy apply \u2014 the assist can complete this one." : "This one applies on the employer's own site."
      ));
      const card = mkEl("div", "margin:6px 0;padding:12px;background:#1e293b;border-radius:6px;display:flex;flex-direction:column;gap:6px");
      card.appendChild(mkEl("div", "font-weight:700;font-size:16px;line-height:1.3", job.title));
      card.appendChild(mkEl("div", "font-size:14px;opacity:.9", job.company));
      card.appendChild(mkEl("div", "font-size:13px;opacity:.8", job.location));
      if (job.pay) {
        card.appendChild(mkEl("div", "font-size:16px;font-weight:800;color:#4ade80", job.pay));
      }
      if (job.snippet && job.snippet !== "N/A") {
        const brief = job.snippet.length > 220 ? `${job.snippet.slice(0, 220)}\u2026` : job.snippet;
        card.appendChild(mkEl("div", "font-size:13px;opacity:.8;line-height:1.5", brief));
      }
      reviewEl.appendChild(card);
      const advance = async () => {
        const next = {
          ...queue,
          cursor: queue.cursor + 1,
          // Capped so a long session can't grow this without bound.
          seen: [...queue.seen.filter((l) => l !== job.link), job.link].slice(-200)
        };
        await setItem("jobQueue", next);
        return next;
      };
      const isLast = queue.cursor >= queue.jobs.length - 1;
      const row = mkEl("div", "display:flex;flex-direction:column;gap:6px;margin-top:6px");
      row.appendChild(makePrimary(mkBtn("Apply to this job", "#059669", async () => {
        await advance();
        await setItem("autoApply", { at: Date.now(), link: job.link });
        window.location.assign(job.link);
      })));
      row.appendChild(makePrimary(
        isLast ? mkBtn("Next page of results \u2192", "#2563eb", goNextPage) : mkBtn("Next job \u2192", "#475569", async () => renderJobBrowser(await advance()))
      ));
      reviewEl.appendChild(row);
    }
    function pickResume() {
      const picker = document.createElement("input");
      picker.type = "file";
      picker.accept = ".pdf,.doc,.docx,.rtf,.txt";
      picker.style.display = "none";
      picker.setAttribute("data-aaui-ignore", "1");
      picker.addEventListener("change", async () => {
        const f = picker.files?.[0];
        picker.remove();
        if (!f) return;
        if (f.size > MAX_RESUME_BYTES) {
          log(`resume too large (${(f.size / 1024 / 1024).toFixed(1)}MB, 4MB max)`, false);
          return;
        }
        try {
          const bytes = new Uint8Array(await f.arrayBuffer());
          await setItem("resume", {
            name: f.name,
            type: f.type,
            data: toBase64(bytes),
            size: f.size,
            savedAt: Date.now()
          });
          log(`resume saved: ${f.name}`, true);
        } catch (err) {
          log(`couldn't save resume: ${err.message}`, false);
        }
      });
      document.documentElement.appendChild(picker);
      picker.click();
    }
    async function advancePage() {
      const btn = await waitFor(() => findAdvanceDom(), 6e3, 250);
      if (!btn) {
        log("no visible Continue/Submit button found", false);
        return false;
      }
      await sleep(PACE_MS);
      const label = (btn.textContent || "").trim();
      if (/\b(submit|send)\b/i.test(label)) {
        log(
          `all filled in \u2014 read it over and press \u201C${label.slice(0, 40)}\u201D yourself. I don't send applications for you.`,
          true
        );
        return false;
      }
      log(`clicking "${label.slice(0, 40)}"`);
      btn.click();
      return true;
    }
    function renderReviewGate(runId, mode = "review") {
      stopBusy();
      reviewEl.innerHTML = "";
      reviewEl.appendChild(
        mode === "paused" ? hHeader("Paused \u2014 your turn", "Assist is hands-off. Edit below or on the page, then resume.") : hHeader("Does this look right?", "Edit anything below \u2014 changes apply to the form.")
      );
      const cards = questions.map((q) => {
        const card = renderQuestionCard(q);
        reviewEl.appendChild(card);
        return { q, card };
      });
      const notice = (text) => {
        let n = reviewEl.querySelector("#aaui-gate-notice");
        if (!n) {
          n = mkEl("div", "margin:6px 0;padding:6px 8px;background:#7f1d1d;border-radius:6px;color:#fff;font-size:11px");
          n.id = "aaui-gate-notice";
          reviewEl.insertBefore(n, reviewEl.firstChild);
        }
        n.textContent = text;
      };
      const footer = mkEl("div", "display:flex;flex-direction:column;gap:6px;margin-top:8px");
      if (mode === "paused") {
        footer.appendChild(makePrimary(mkBtn("Resume assist", "#7c3aed", () => sendToWorker2({ type: "resume-run", runId }))));
      } else {
        footer.appendChild(makePrimary(mkBtn("Looks right \u2192 Continue", "#059669", () => {
          const missing = cards.filter(({ q }) => isFieldRequired(q) && !isFieldAnswered(q));
          if (missing.length) {
            for (const { card } of cards) card.style.outline = "";
            for (const { card } of missing) card.style.outline = "2px solid #f87171";
            const plural = missing.length > 1;
            notice(
              `${missing.length} required question${plural ? "s" : ""} still need${plural ? "" : "s"} an answer \u2014 fill the highlighted card${plural ? "s" : ""} below (or use \u201CPause\u201D to answer on the page), then Continue.`
            );
            missing[0].card.scrollIntoView({ block: "nearest" });
            return;
          }
          reviewEl.innerHTML = "";
          sendToWorker2({ type: "review-decision", runId, decision: "approved" });
        })));
      }
      const row = mkEl("div", "display:flex;gap:6px");
      if (mode !== "paused") {
        row.appendChild(mkBtn("Pause \u2014 I'll do it myself", "#475569", () => {
          sendToWorker2({ type: "pause-run", runId });
          renderReviewGate(runId, "paused");
        }));
      }
      row.appendChild(mkBtn("Stop", "#b91c1c", () => {
        reviewEl.innerHTML = "";
        sendToWorker2({ type: "review-decision", runId, decision: "rejected" });
      }));
      footer.appendChild(row);
      reviewEl.appendChild(footer);
      if (mode === "paused") return;
      if (cards.some(({ q }) => isFieldRequired(q) && !isFieldAnswered(q))) return;
      const advanceLabel = (findAdvanceDom()?.innerText || "").trim();
      if (/\b(submit|send)\b/i.test(advanceLabel)) {
        notice(`Ready to submit \u2014 press \u201C${advanceLabel || "Continue"}\u201D yourself when you've checked it.`);
        return;
      }
      const bar = mkEl("div", "display:flex;align-items:center;gap:6px;margin-top:6px;font-size:11px;opacity:.9");
      const label = mkEl("span", "flex:1");
      const cancel = document.createElement("button");
      cancel.textContent = "Cancel";
      cancel.style.cssText = "border:0;border-radius:4px;padding:4px 8px;background:#475569;color:#fff;cursor:pointer;font:inherit";
      bar.append(label, cancel);
      reviewEl.appendChild(bar);
      let left = 4;
      label.textContent = `Everything answered \u2014 continuing in ${left}\u2026`;
      const tick = setInterval(() => {
        left -= 1;
        if (left > 0) {
          label.textContent = `Everything answered \u2014 continuing in ${left}\u2026`;
          return;
        }
        clearInterval(tick);
        reviewEl.innerHTML = "";
        sendToWorker2({ type: "review-decision", runId, decision: "approved" });
      }, 1e3);
      cancel.addEventListener("click", () => {
        clearInterval(tick);
        bar.remove();
      });
    }
    function renderQuestionCard(q) {
      const card = mkEl("div", "margin:6px 0;padding:8px;background:#1e293b;border-radius:6px");
      card.appendChild(mkEl("div", "font-weight:600;margin-bottom:2px", q.text.slice(0, 120)));
      const meta = mkEl("div", "opacity:.55;font-size:11px;margin-bottom:6px", q.type + (q.options.length ? ` \xB7 ${q.options.length} options` : ""));
      card.appendChild(meta);
      card.appendChild(buildControl(q, (filled) => {
        meta.textContent = q.type + (q.options.length ? ` \xB7 ${q.options.length} options` : "") + (filled ? "  \u2713 filled" : "  \u2014 needs you");
        meta.style.color = filled ? "#4ade80" : "#fbbf24";
      }));
      return card;
    }
    function buildControl(q, onState) {
      const t = q.type;
      if (t === "checkbox" || t === "radio") {
        const wrap = mkEl("div", "display:flex;flex-direction:column;gap:4px");
        const groupName = `aaui-${Math.random().toString(36).slice(2)}`;
        const syncState = () => onState(q.options.some((o) => realOptionEl(q, o)?.checked));
        for (const opt of q.options) {
          const realEl2 = realOptionEl(q, opt);
          const lbl = mkEl("label", "display:flex;align-items:center;gap:6px;cursor:pointer");
          const box = document.createElement("input");
          box.type = t === "radio" ? "radio" : "checkbox";
          if (t === "radio") box.name = groupName;
          box.checked = !!realEl2?.checked;
          box.addEventListener("change", () => {
            if (realEl2 && realEl2.checked !== box.checked) realEl2.click();
            setTimeout(() => {
              box.checked = !!realEl2?.checked;
              syncState();
            }, 0);
          });
          lbl.appendChild(box);
          lbl.appendChild(mkEl("span", "", opt.label.slice(0, 60)));
          wrap.appendChild(lbl);
        }
        syncState();
        return wrap;
      }
      if (t === "select") {
        const realEl2 = realSelectEl(q);
        const sel = document.createElement("select");
        sel.style.cssText = "width:100%;padding:4px;border:1px solid #334155;border-radius:4px;background:#0f172a;color:#e2e8f0";
        const blank = document.createElement("option");
        blank.value = "";
        blank.textContent = "\u2014 select \u2014";
        sel.appendChild(blank);
        for (const opt of q.options) {
          const o = document.createElement("option");
          o.value = opt.value;
          o.textContent = opt.label.slice(0, 60);
          sel.appendChild(o);
        }
        sel.value = realEl2?.value ?? "";
        sel.addEventListener("change", () => {
          if (realEl2) setNativeValue(realEl2, sel.value);
          setTimeout(() => {
            sel.value = realEl2?.value ?? "";
            onState(!!realEl2?.value);
          }, 0);
        });
        onState(!!realEl2?.value);
        return sel;
      }
      if (t === "combobox") {
        const realEl2 = realComboboxEl(q);
        const wrap = mkEl("div", "display:flex;flex-direction:column;gap:4px");
        const current = mkEl("div", "opacity:.8;font-size:11px", `current: ${(realEl2?.innerText || "(nothing)").trim().slice(0, 40)}`);
        wrap.appendChild(current);
        wrap.appendChild(mkBtn("Choose on page \u25BE", "#2563eb", () => {
          realEl2?.click();
          realEl2?.focus?.();
          setTimeout(() => {
            current.textContent = `current: ${(realEl2?.innerText || "(nothing)").trim().slice(0, 40)}`;
            onState(!!realEl2 && !/^\s*(select an option|nothing)?\s*$/i.test(realEl2.innerText || ""));
          }, 1500);
        }));
        onState(!!realEl2 && !/select an option/i.test(realEl2.innerText || ""));
        return wrap;
      }
      const realEl = realTextEl(q);
      const input = t === "textarea" ? document.createElement("textarea") : document.createElement("input");
      input.style.cssText = "width:100%;padding:4px;border:1px solid #334155;border-radius:4px;background:#0f172a;color:#e2e8f0";
      input.value = realEl?.value ?? "";
      input.addEventListener("input", () => {
        if (realEl) setNativeValue(realEl, input.value);
        onState(!!input.value.trim());
      });
      onState(!!realEl?.value?.trim());
      return input;
    }
    function renderTemplateEditor() {
      reviewEl.innerHTML = "";
      reviewEl.appendChild(hHeader("Answer template", "Your saved answers drive the autofill. Blank = sensible default."));
      if (usingSynced) {
        const note = mkEl(
          "div",
          "margin:4px 0 8px;padding:6px;background:#1e293b;border:1px solid #2563eb;border-radius:6px;font-size:11px;line-height:1.4",
          "Showing your web-app template. Edit it at jobassistui.com \u2192 Answer Template. Saving here only sets a local fallback used when signed out."
        );
        reviewEl.appendChild(note);
      }
      const cfg = template?.config ?? {};
      const fieldInputs = {};
      for (const f of TEMPLATE_FIELDS) {
        const card = mkEl("div", "margin:5px 0");
        card.appendChild(mkEl("div", "font-size:11px;opacity:.8;margin-bottom:2px", f.label));
        let inp;
        if (f.type === "yesno" || f.type === "select") {
          const sel = document.createElement("select");
          sel.style.cssText = INPUT_CSS;
          const choices = f.type === "yesno" ? [{ label: "(default)", value: "" }, { label: "Yes", value: "Yes" }, { label: "No", value: "No" }] : [{ label: "(default)", value: "" }, ...f.options ?? []];
          for (const c of choices) {
            const opt = document.createElement("option");
            opt.value = c.value;
            opt.textContent = c.label;
            sel.appendChild(opt);
          }
          sel.value = choices.some((c) => c.value === cfg[f.key]) ? cfg[f.key] ?? "" : "";
          inp = sel;
        } else {
          const t = document.createElement("input");
          t.style.cssText = INPUT_CSS;
          t.value = cfg[f.key] ?? "";
          if (f.placeholder) t.placeholder = f.placeholder;
          inp = t;
        }
        fieldInputs[f.key] = inp;
        card.appendChild(inp);
        reviewEl.appendChild(card);
      }
      reviewEl.appendChild(mkEl("div", "font-weight:700;margin:12px 0 2px", "Custom question rules"));
      reviewEl.appendChild(mkEl("div", "font-size:11px;opacity:.6;margin-bottom:4px", "If a question contains \u2026 answer \u2026  (these win over the built-in rules)"));
      const rulesWrap = mkEl("div", "");
      reviewEl.appendChild(rulesWrap);
      const addRuleRow = (rule) => {
        const row = mkEl("div", "display:flex;gap:4px;margin:3px 0");
        const m = document.createElement("input");
        m.placeholder = "contains\u2026";
        m.style.cssText = INPUT_CSS + ";flex:1";
        m.value = rule?.match ?? "";
        const a = document.createElement("input");
        a.placeholder = "answer";
        a.style.cssText = INPUT_CSS + ";flex:1";
        a.value = rule?.answer ?? "";
        const del = mkBtn("\xD7", "#b91c1c", () => row.remove());
        del.style.flex = "0 0 26px";
        row.append(m, a, del);
        rulesWrap.appendChild(row);
      };
      (template?.rules ?? []).forEach((r) => addRuleRow(r));
      const add = mkBtn("+ Add rule", "#334155", () => addRuleRow());
      add.style.marginTop = "4px";
      reviewEl.appendChild(add);
      const footer = mkEl("div", "display:flex;gap:6px;margin-top:12px");
      footer.appendChild(mkBtn("Save template", "#059669", async () => {
        const config = {};
        for (const f of TEMPLATE_FIELDS) {
          const v = fieldInputs[f.key].value.trim();
          if (v) config[f.key] = v;
        }
        const rules = [];
        for (const row of Array.from(rulesWrap.children)) {
          const ins = row.querySelectorAll("input");
          const match = ins[0]?.value.trim() ?? "";
          const answer = ins[1]?.value.trim() ?? "";
          if (match && answer) rules.push({ match, answer });
        }
        await setItem("template", { config, rules });
        await loadTemplate();
        reviewEl.innerHTML = "";
        log(`template saved (${Object.keys(config).length} fields, ${rules.length} rules)`, true);
      }));
      footer.appendChild(mkBtn("Cancel", "#475569", () => {
        reviewEl.innerHTML = "";
      }));
      reviewEl.appendChild(footer);
    }
    function submitLog(employer, jobTitle, url) {
      sendToWorker2({ type: "log-activity", employer_name: employer, job_title: jobTitle, url });
    }
    function renderLogConfirm(job) {
      reviewEl.innerHTML = "";
      if (job.company) {
        submitLog(job.company, job.title, job.url);
        const done = mkEl("div", "margin:6px 0;padding:8px;background:#064e3b;border:1px solid #059669;border-radius:6px");
        done.appendChild(mkEl("div", "font-weight:700;margin-bottom:2px", "Logged \u2713"));
        done.appendChild(mkEl(
          "div",
          "font-size:11px;line-height:1.4",
          `${job.company}${job.title ? ` \u2014 ${job.title}` : ""}. Syncs to your activity record next time you open the web app. Wrong? Remove it on your dashboard.`
        ));
        reviewEl.appendChild(done);
        log(`logged: ${job.company}`, true);
        return;
      }
      reviewEl.appendChild(hHeader("Application submitted \u{1F389}", "We couldn't read the employer from this page \u2014 add it and we'll log it."));
      const card = mkEl("div", "margin:6px 0;padding:8px;background:#1e293b;border-radius:6px;display:flex;flex-direction:column;gap:6px");
      const empWrap = mkEl("div", "");
      empWrap.appendChild(mkEl("div", "font-size:11px;opacity:.8;margin-bottom:2px", "Employer"));
      const emp = document.createElement("input");
      emp.style.cssText = INPUT_CSS;
      emp.value = job.company ?? "";
      emp.placeholder = "Employer name";
      empWrap.appendChild(emp);
      const titleWrap = mkEl("div", "");
      titleWrap.appendChild(mkEl("div", "font-size:11px;opacity:.8;margin-bottom:2px", "Job title"));
      const title = document.createElement("input");
      title.style.cssText = INPUT_CSS;
      title.value = job.title ?? "";
      title.placeholder = "Job title";
      titleWrap.appendChild(title);
      card.append(empWrap, titleWrap);
      const row = mkEl("div", "display:flex;gap:6px;margin-top:4px");
      row.appendChild(mkBtn("Log it", "#059669", () => {
        const employer = emp.value.trim();
        if (!employer) {
          log("employer is required to log", false);
          return;
        }
        submitLog(employer, title.value.trim() || null, job.url);
        reviewEl.innerHTML = "";
        log("logged \u2014 syncs to your activity record next time you open the web app", true);
      }));
      row.appendChild(mkBtn("Skip", "#475569", () => {
        reviewEl.innerHTML = "";
      }));
      card.appendChild(row);
      reviewEl.appendChild(card);
    }
    panel.querySelector("#aaui-template").addEventListener("click", () => renderTemplateEditor());
    panel.querySelector("#aaui-find").addEventListener("click", () => findJobs());
    panel.querySelector("#aaui-resume").addEventListener("click", () => pickResume());
    getItem("resume").then((r) => {
      if (r) log(`resume ready: ${r.name}`);
    });
    const startBtn = panel.querySelector("#aaui-start");
    const refreshScanEnabled = () => {
      const on = isApplyContext();
      startBtn.style.opacity = on ? "1" : "0.45";
      startBtn.style.cursor = on ? "pointer" : "not-allowed";
      startBtn.title = on ? "" : "Available once you're inside an application form";
      if (on) clearInterval(scanWatch);
    };
    const scanWatch = setInterval(refreshScanEnabled, 1500);
    refreshScanEnabled();
    let startPending = false;
    async function startRun() {
      if (startPending) return;
      startPending = true;
      try {
        const active = await getItem("activeRun");
        if (active && active.status !== "done" && active.status !== "error") {
          log("a run is already active \u2014 press Cancel to stop it before restarting", false);
          return;
        }
        const res = await sendToWorker2({ type: "start-run" });
        if (res?.ok) {
          log("run started", true);
          return;
        }
        if (res?.reason === "not-signed-in") {
          log("Sign in at jobassistui.com to use the assist", false);
        } else if (res?.reason === "not-entitled") {
          log("Account not active \u2014 start your trial / subscribe on the web app, then reload here", false);
        } else {
          log("couldn't start run", false);
        }
      } finally {
        startPending = false;
      }
    }
    startBtn.addEventListener("click", () => {
      if (!isApplyContext()) {
        log("use \u201CFind jobs\u201D here \u2014 rescanning only works inside an application", false);
        return;
      }
      void startRun();
    });
    void (async () => {
      const stamp = await getItem("autoApply");
      if (!stamp || typeof stamp.at !== "number" || Date.now() - stamp.at > AUTO_APPLY_TTL_MS) {
        if (stamp) await setItem("autoApply", null);
        return;
      }
      const wantKey = jobKeyOf(stamp.link);
      if (!isApplyContext() && wantKey && !location.href.includes(wantKey)) {
        await setItem("autoApply", null);
        log("this isn't the job you picked \u2014 apply intent dropped");
        return;
      }
      if (isApplyPage()) {
        await setItem("autoApply", null);
        await loadTemplate();
        showBusy("Reading the application");
        await waitFor(
          () => document.querySelector('input[type="radio"], input[type="checkbox"], select, textarea, input[type="text"]'),
          8e3
        );
        hideBusy();
        renderStartConfirm(captureJobMeta());
        return;
      }
      if (/^\/jobs\b/.test(location.pathname)) return;
      showBusy("Opening the application");
      await sleep(1200);
      const btn = await waitFor(findIndeedApplyDom, 8e3);
      if (!btn) {
        await setItem("autoApply", null);
        failBusy("Couldn't find Indeed's Apply button on this page \u2014 press it yourself, then \u201C\u21BB Rescan page\u201D.");
        return;
      }
      for (let attempt = 1; attempt <= 4; attempt++) {
        if (isApplyContext()) return;
        log(attempt === 1 ? "clicking Apply with Indeed" : `Apply didn't take \u2014 retry ${attempt - 1}`);
        const res = await sendToWorker2({ type: "click-apply" });
        log(res ? `in-page press: ${res.ok ? res.how : `failed (${res.how ?? "no result"})`}` : "in-page press: worker unavailable", res?.ok === true);
        if (!res?.ok) realClick(btn);
        await sleep(1800);
        if (isApplyContext()) return;
      }
      await setItem("autoApply", { at: Date.now(), link: stamp.link });
      failBusy("Couldn't press Apply for you. Press \u201CApply with Indeed\u201D yourself \u2014 the assist takes over as soon as the form opens.");
    })();
    panel.querySelector("#aaui-cancel").addEventListener("click", () => {
      sendToWorker2({ type: "cancel-run" }).then(() => log("run cancelled"));
    });
    chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
      if (msg?.type === "confirm-log") {
        renderLogConfirm(msg.job);
        sendResponse({ ok: true });
        return false;
      }
      if (msg?.type !== "command") return false;
      switch (msg.command) {
        case "scan": {
          void (async () => {
            let { found, hadControls } = await scanWhenReady();
            for (let hop = 0; !found.length && !hadControls && hop < 4 && isApplyContext(); hop++) {
              const next = findAdvanceDom();
              if (!next) break;
              const nextLabel = (next.innerText || "").trim();
              if (/\b(submit|send)\b/i.test(nextLabel)) {
                log(
                  `all filled in \u2014 read it over and press \u201C${nextLabel.slice(0, 40)}\u201D yourself. I don't send applications for you.`,
                  true
                );
                break;
              }
              sendToWorker2({ type: "scan-progress", runId: msg.runId });
              log(`no questions here \u2014 ${(next.innerText || "continuing").trim().slice(0, 24)}`);
              next.click();
              await sleep(PACE_MS);
              ({ found, hadControls } = await scanWhenReady());
            }
            const job = captureJobMeta();
            if (job.title || job.company) {
              sendToWorker2({ type: "job-meta", runId: msg.runId, job });
            }
            if (!isApplyPage()) {
              if (isTop && !hasApplyFrame()) {
                sendToWorker2({ type: "scan-result", runId: msg.runId, questions: [], job });
              }
              return;
            }
            if (found.length > 0) {
              sendToWorker2({ type: "scan-result", runId: msg.runId, questions: found, job });
              return;
            }
            if (hadControls) {
              failBusy("Found form controls on this page but couldn't read any questions. Fill this page yourself \u2014 the log line below has what the scraper saw.");
              sendToWorker2({ type: "run-error", runId: msg.runId, reason: `unreadable form (${domSummary()})` });
              return;
            }
            sendToWorker2({ type: "scan-result", runId: msg.runId, questions: [], job });
          })();
          sendResponse({ ok: true });
          return false;
        }
        case "fill": {
          fillPage().then(() => sendToWorker2({ type: "fill-result", runId: msg.runId })).catch((err) => sendToWorker2({ type: "run-error", runId: msg.runId, reason: String(err) }));
          sendResponse({ ok: true });
          return false;
        }
        case "review": {
          renderReviewGate(msg.runId);
          sendResponse({ ok: true });
          return false;
        }
        case "advance": {
          sendResponse({ ok: true });
          void advancePage().then((ok) => {
            if (!ok) {
              sendToWorker2({ type: "run-error", runId: msg.runId, reason: "no advance button" });
            }
          });
          return false;
        }
      }
    });
  }
  function setNativeValue(el, value) {
    const proto = el instanceof HTMLTextAreaElement ? HTMLTextAreaElement.prototype : el instanceof HTMLSelectElement ? HTMLSelectElement.prototype : HTMLInputElement.prototype;
    const setter = Object.getOwnPropertyDescriptor(proto, "value")?.set;
    setter?.call(el, value);
    el.dispatchEvent(new Event("input", { bubbles: true }));
    el.dispatchEvent(new Event("change", { bubbles: true }));
  }
  function settled() {
    return new Promise(
      (r) => requestAnimationFrame(() => requestAnimationFrame(() => setTimeout(r, 40)))
    );
  }
  async function stickValue(el, want) {
    await settled();
    if (el.value === want) return true;
    setNativeValue(el, want);
    await settled();
    return el.value === want;
  }
  var INPUT_CSS = "width:100%;padding:4px;border:1px solid #334155;border-radius:4px;background:#0f172a;color:#e2e8f0;font:inherit;box-sizing:border-box";
  var TEMPLATE_FIELDS = [
    { key: "firstName", label: "First name" },
    { key: "lastName", label: "Last name" },
    { key: "phone", label: "Phone" },
    { key: "zipCode", label: "ZIP code" },
    { key: "city", label: "City" },
    { key: "educationLevel", label: "Education", placeholder: "keywords to match the option, e.g. Bachelor" },
    { key: "salary", label: "Desired salary" },
    { key: "yearsExperience", label: "Years of experience" },
    { key: "willingToRelocate", label: "Willing to relocate", type: "yesno" },
    { key: "authorizedToWork", label: "Authorized to work in the US", type: "yesno" },
    { key: "needsSponsorship", label: "Need visa sponsorship", type: "yesno" },
    { key: "usCitizen", label: "US citizen", type: "yesno" },
    { key: "is18OrOlder", label: "18 or older", type: "yesno" },
    { key: "hasDiploma", label: "Have HS diploma / GED", type: "yesno" },
    { key: "drivingLicense", label: "Have driver's license", type: "yesno" },
    {
      key: "veteranStatus",
      label: "Veteran status",
      type: "select",
      options: [
        { label: "Not a protected veteran", value: "not a protected veteran" },
        { label: "I am a protected veteran", value: "i identify as a protected veteran" },
        { label: "Prefer not to answer", value: "prefer not to answer" }
      ]
    },
    {
      key: "disabilityStatus",
      label: "Disability status",
      type: "select",
      options: [
        { label: "No, I don't have a disability", value: "no i do not have a disability" },
        { label: "Yes, I have a disability", value: "yes i have a disability" },
        { label: "Prefer not to answer", value: "prefer not to answer" }
      ]
    },
    { key: "linkedin", label: "LinkedIn URL" },
    { key: "priorJobTitle", label: "Most recent job title" },
    { key: "priorJobCompany", label: "Most recent employer" },
    { key: "priorJobDuration", label: "Time at most recent job", placeholder: "e.g. 3 years" },
    { key: "timeZone", label: "Time zone", placeholder: "e.g. Eastern" },
    { key: "preferredDay", label: "Preferred interview day", placeholder: "e.g. Monday" },
    { key: "preferredTime", label: "Preferred interview time", placeholder: "e.g. Morning" },
    { key: "searchQuery", label: "Search: job title or keywords", placeholder: "e.g. production technician" },
    { key: "searchLocation", label: "Search: location", placeholder: "blank searches everywhere" },
    { key: "maxApplications", label: "Max applications per session", placeholder: "e.g. 5" },
    { key: "exclusionTitleRegex", label: "Skip titles matching", placeholder: "e.g. senior|manager" },
    { key: "referralCompanies", label: "Employers who referred you", placeholder: "Byrne Dairy: Bob Jones; Acme: Sue Lee" },
    { key: "relativeCompanies", label: "Employers where you know someone", placeholder: "Byrne Dairy: Jane Smith" }
  ];
  function mergedConfig(template) {
    const cfg = { ...DEFAULT_CONFIG };
    for (const [k, v] of Object.entries(template?.config ?? {})) {
      if (v != null && String(v).trim() !== "") cfg[k] = v;
    }
    return cfg;
  }
  function parseContacts(raw) {
    if (!raw) return [];
    return raw.split(/[\n;]+/).map((line) => line.trim()).filter(Boolean).map((line) => {
      const m = /^([^:]+):\s*(.*)$/.exec(line) ?? /^(.+?)\s+[-–]\s+(.*)$/.exec(line);
      return m ? { company: m[1].trim(), name: m[2].trim() } : { company: line, name: "" };
    }).filter((c) => c.company.length > 0);
  }
  var COMPANY_NOISE = /\b(inc|llc|ltd|limited|corp|corporation|company|co|group|holdings|plc|the)\b/g;
  function normalizeCompany(s) {
    return s.toLowerCase().replace(/[^a-z0-9 ]/g, " ").replace(COMPANY_NOISE, " ").replace(/\s+/g, " ").trim();
  }
  function matchContact(list, company) {
    const target = normalizeCompany(company ?? "");
    if (!target) return null;
    for (const c of list) {
      const n = normalizeCompany(c.company);
      if (!n) continue;
      if (n === target) return c;
      if (n.length >= 4 && (target.includes(n) || n.includes(target))) return c;
    }
    return null;
  }
  var MAX_RESUME_BYTES = 4 * 1024 * 1024;
  function resumeToFile(r) {
    const bin = atob(r.data);
    const bytes = new Uint8Array(bin.length);
    for (let i = 0; i < bin.length; i++) bytes[i] = bin.charCodeAt(i);
    return new File([bytes], r.name, { type: r.type || "application/octet-stream" });
  }
  function toBase64(bytes) {
    let bin = "";
    const CHUNK = 32768;
    for (let i = 0; i < bytes.length; i += CHUNK) {
      bin += String.fromCharCode(...bytes.subarray(i, i + CHUNK));
    }
    return btoa(bin);
  }
  async function attachResumeDom(resume) {
    const target = Array.from(document.querySelectorAll('input[type="file"]')).find((el) => {
      if (el.disabled) return false;
      if ((el.files?.length ?? 0) > 0) return false;
      const accept = (el.accept || "").toLowerCase();
      return !accept || !/^[\s,]*image\//.test(accept);
    });
    if (!target) return null;
    try {
      const dt = new DataTransfer();
      dt.items.add(resumeToFile(resume));
      target.files = dt.files;
      target.dispatchEvent(new Event("input", { bubbles: true }));
      target.dispatchEvent(new Event("change", { bubbles: true }));
      await settled();
      const ok = (target.files?.length ?? 0) > 0;
      return { ok, detail: ok ? `attached ${resume.name}` : "the file input rejected the attachment" };
    } catch (err) {
      return { ok: false, detail: err.message };
    }
  }
  function captureJobMeta() {
    const pick = (sel) => {
      const el = document.querySelector(sel);
      const t = el?.innerText?.trim();
      return t && t.length > 0 && t.length < 200 ? t : null;
    };
    const meta = (name) => {
      const el = document.querySelector(
        `meta[property="${name}"], meta[name="${name}"]`
      );
      const c = el?.content?.trim();
      return c && c.length > 0 && c.length < 200 ? c : null;
    };
    let title = pick('[data-testid*="jobTitle" i]') || pick('[data-testid*="job-title" i]') || pick('[data-testid="jobsearch-JobInfoHeader-title"]') || pick('[class*="JobInfoHeader-title" i]') || pick('[class*="jobTitle" i]') || pick("h1") || meta("og:title");
    let company = pick('[data-testid*="companyName" i]') || pick('[data-testid*="company-name" i]') || pick('[data-testid*="employerName" i]') || pick('[data-testid="inlineHeader-companyName"]') || pick("[data-company-name]") || pick('[class*="CompanyInfoContainer" i] a') || pick('[class*="companyName" i]') || // Indeed links an employer's profile at /cmp/<company>; on the apply flow's
    // job card that link is often the only place the name is marked up at all.
    pick('a[href*="/cmp/"]');
    if (!title || !company) {
      const parts = document.title.split(/\s+[-–|]\s+/).map((s) => s.trim()).filter((s) => s && !/^indeed(\.com)?$/i.test(s) && !/^(apply|job application)\b/i.test(s));
      if (!title && parts[0]) title = parts[0];
      if (!company && parts[1]) company = parts[1];
    }
    const jobLink = document.querySelector('a[href*="/viewjob"], a[href*="/rc/clk"]');
    const url = jobLink?.href || location.href;
    return { title: title ?? null, company: company ?? null, url };
  }
  function mkEl(tag, css, text) {
    const e = document.createElement(tag);
    if (css) e.style.cssText = css;
    if (text != null) e.textContent = text;
    return e;
  }
  function makePrimary(b) {
    b.style.padding = "14px 10px";
    b.style.fontSize = "15px";
    b.style.fontWeight = "700";
    b.style.borderRadius = "8px";
    return b;
  }
  function mkBtn(label, bg, onClick) {
    const b = document.createElement("button");
    b.textContent = label;
    b.style.cssText = `flex:1;padding:10px 8px;font-size:13px;border:0;border-radius:6px;background:${bg};color:#fff;cursor:pointer;font-family:inherit`;
    b.addEventListener("click", onClick);
    return b;
  }
  function hHeader(title, sub) {
    const box = mkEl("div", "margin:4px 0 6px");
    box.appendChild(mkEl("div", "font-weight:700", title));
    box.appendChild(mkEl("div", "opacity:.6;font-size:11px", sub));
    return box;
  }
  function realTextEl(q) {
    if (q.inputId) return document.getElementById(q.inputId);
    if (q.inputName) {
      return document.querySelector(
        `input[name="${CSS.escape(q.inputName)}"], textarea[name="${CSS.escape(q.inputName)}"]`
      );
    }
    return null;
  }
  function realOptionEl(q, opt) {
    if (opt.id) return document.getElementById(opt.id);
    if (q.inputName) {
      return document.querySelector(
        `input[name="${CSS.escape(q.inputName)}"][value="${CSS.escape(opt.value)}"]`
      );
    }
    return null;
  }
  function realSelectEl(q) {
    return q.inputId ? document.getElementById(q.inputId) : null;
  }
  function realComboboxEl(q) {
    return q.inputId ? document.getElementById(q.inputId) : null;
  }
  function isFieldRequired(q) {
    if (q.text.trim().endsWith("*")) return true;
    const els = q.type === "radio" || q.type === "checkbox" ? q.options.map((o) => realOptionEl(q, o)) : q.type === "select" ? [realSelectEl(q)] : q.type === "combobox" ? [realComboboxEl(q)] : [realTextEl(q)];
    return els.some(
      (el) => !!el && (el.required === true || el.getAttribute("aria-required") === "true")
    );
  }
  function isFieldAnswered(q) {
    switch (q.type) {
      case "radio":
      case "checkbox":
        return q.options.some((o) => realOptionEl(q, o)?.checked);
      case "select":
        return !!realSelectEl(q)?.value;
      case "combobox": {
        const t = (realComboboxEl(q)?.innerText || "").trim();
        return !!t && !/select an option/i.test(t);
      }
      default:
        return !!realTextEl(q)?.value?.trim();
    }
  }
  function classifyIntent(text) {
    const s = text.toLowerCase();
    if (/\b(decline|prefer not|choose not|no answer|not to answer|no response|wish to answer|want to answer|not to self.?identify|skip|n\/?a)\b/.test(s)) return "decline";
    if (/\b(none|no|not|nope|never|am not|do not|without)\b/.test(s)) return "negative";
    if (/\b(yes|i am|i have|identify|affirm|yeah|yep)\b/.test(s)) return "affirmative";
    return "neutral";
  }
  function scoreOption(label, answer) {
    const o = label.toLowerCase().trim();
    const a = answer.toLowerCase().trim();
    if (!o || !a) return 0;
    if (o === a) return 1e3;
    const oTokens = new Set(o.split(/[^a-z0-9]+/).filter(Boolean));
    let score = 0;
    for (const t of a.split(/[^a-z0-9]+/)) if (t.length > 2 && oTokens.has(t)) score += 10;
    if (o.length >= 4 && a.includes(o)) score += 20;
    if (a.length >= 4 && o.includes(a)) score += 20;
    const ai = classifyIntent(a);
    const oi = classifyIntent(o);
    if (ai !== "neutral" && oi !== "neutral") score += ai === oi ? 100 : -100;
    return score;
  }
  function resolveOptionIndex(options, answer) {
    const trimmed = answer.trim();
    if (!answer.startsWith("__RADIO:") && /^\d+$/.test(trimmed)) {
      const i = parseInt(trimmed, 10);
      if (i >= 1 && i <= options.length) return i - 1;
    }
    const raw = answer.startsWith("__RADIO:") ? answer.slice(8) : answer;
    const keywords = raw.split(",").map((k) => k.trim()).filter(Boolean);
    let bestIdx = -1;
    let bestScore = 0;
    for (const kw of keywords) {
      for (let i = 0; i < options.length; i++) {
        const s = scoreOption(options[i].label, kw);
        if (s > bestScore) {
          bestScore = s;
          bestIdx = i;
        }
      }
    }
    return bestScore > 0 ? bestIdx : -1;
  }
  async function waitFor(fn, timeoutMs, stepMs = 60) {
    const deadline = Date.now() + timeoutMs;
    for (; ; ) {
      const v = fn();
      if (v) return v;
      if (Date.now() >= deadline) return null;
      await sleep(stepMs);
    }
  }
  async function fillComboboxDom(field, answer) {
    const combo = field.inputId ? document.getElementById(field.inputId) : null;
    if (!combo) return { ok: false, detail: "combobox not found" };
    const keywords = (answer.startsWith("__RADIO:") ? answer.slice(8) : answer).split(",").map((k) => k.trim().toLowerCase()).filter(Boolean);
    if (!keywords.length) return { ok: false, detail: "no answer to match" };
    const popupId = combo.getAttribute("aria-controls");
    if (combo.getAttribute("aria-expanded") !== "true") combo.click();
    const popup = await waitFor(() => {
      const p = popupId ? document.getElementById(popupId) : null;
      const scope = p || document.querySelector('[role="dialog"], [role="listbox"]');
      return scope && scope.querySelector('input[type="checkbox"], input[type="radio"], [role="option"]') ? scope : null;
    }, 1500);
    if (!popup) return { ok: false, detail: "options popup did not open" };
    const optionEls = Array.from(popup.querySelectorAll('label, [role="option"]'));
    let picked = null;
    let pickedLabel = "";
    let bestScore = 0;
    for (const el of optionEls) {
      const txt = (el.innerText || "").trim();
      if (!txt) continue;
      let s = 0;
      for (const kw of keywords) s = Math.max(s, scoreOption(txt, kw));
      if (s > bestScore) {
        bestScore = s;
        picked = el;
        pickedLabel = txt;
      }
    }
    if (!picked || bestScore <= 0) {
      closeCombo(combo);
      return { ok: false, detail: `no dropdown option matched "${keywords[0]}"` };
    }
    const control = picked.querySelector('input[type="checkbox"], input[type="radio"]');
    if (control) {
      if (!control.checked) control.click();
    } else {
      picked.click();
    }
    closeCombo(combo);
    await sleep(150);
    const display = (combo.innerText || "").trim();
    const stuck = (control ? control.checked : true) || /selected/i.test(display) || display.length > 0 && !/select an option/i.test(display);
    return {
      ok: stuck,
      detail: stuck ? `selected "${pickedLabel.slice(0, 40)}"` : `clicked "${pickedLabel.slice(0, 40)}" \u2014 may not have stuck`
    };
  }
  function closeCombo(combo) {
    const esc = () => new KeyboardEvent("keydown", { key: "Escape", code: "Escape", bubbles: true });
    (document.activeElement || combo).dispatchEvent(esc());
    combo.dispatchEvent(esc());
  }
  async function fillFieldDom(field, answer) {
    try {
      if (field.type === "combobox") {
        return await fillComboboxDom(field, answer);
      }
      if (field.type === "radio" || field.type === "checkbox") {
        const oi = resolveOptionIndex(field.options, answer);
        if (oi < 0) return { ok: false, detail: "no matching option" };
        const opt = field.options[oi];
        const el2 = opt.id ? document.getElementById(opt.id) : field.inputName ? document.querySelector(`input[name="${CSS.escape(field.inputName)}"][value="${CSS.escape(opt.value)}"]`) : null;
        if (!el2) return { ok: false, detail: "option element not found" };
        const cbEl = el2;
        if (!cbEl.checked) cbEl.click();
        await settled();
        const checked = cbEl.checked;
        return { ok: checked, detail: checked ? `selected "${opt.label}"` : `could not check "${opt.label}"` };
      }
      if (field.type === "select") {
        const oi = resolveOptionIndex(field.options, answer);
        const match = oi >= 0 ? field.options[oi] : null;
        if (!match || !field.inputId) return { ok: false, detail: "no matching option" };
        const el2 = document.getElementById(field.inputId);
        if (!el2) return { ok: false, detail: "select not found" };
        setNativeValue(el2, match.value);
        const held = await stickValue(el2, match.value);
        return {
          ok: held,
          detail: held ? `selected "${match.label}"` : `selection did NOT stick for "${match.label}"`
        };
      }
      const el = field.inputId ? document.getElementById(field.inputId) : field.inputName ? document.querySelector(`input[name="${CSS.escape(field.inputName)}"], textarea[name="${CSS.escape(field.inputName)}"]`) : null;
      if (!el) return { ok: false, detail: "input not found" };
      const text = answer.startsWith("__RADIO:") ? (answer.slice(8).split(",")[0] ?? "").trim() : answer;
      if (!text) return { ok: false, detail: "no answer to fill" };
      el.focus();
      setNativeValue(el, text);
      el.dispatchEvent(new Event("blur", { bubbles: true }));
      const stuck = await stickValue(el, text);
      return { ok: stuck, detail: stuck ? `filled "${text}"` : "value did NOT stick (React reverted it)" };
    } catch (err) {
      return { ok: false, detail: err.message };
    }
  }
  var AUTO_APPLY_TTL_MS = 12e4;
  function jobKeyOf(url) {
    try {
      return new URL(url, location.href).searchParams.get("jk");
    } catch {
      return null;
    }
  }
  function realClick(el) {
    const init2 = { bubbles: true, cancelable: true, view: window };
    const press = (t) => {
      t.dispatchEvent(new PointerEvent("pointerdown", init2));
      t.dispatchEvent(new MouseEvent("mousedown", init2));
      t.dispatchEvent(new PointerEvent("pointerup", init2));
      t.dispatchEvent(new MouseEvent("mouseup", init2));
      t.click();
    };
    press(el);
    const inner = el.querySelector('button, [role="button"]');
    if (inner && inner !== el) press(inner);
  }
  function findIndeedApplyDom() {
    const wrapper = Array.from(
      document.querySelectorAll(
        '[class*="indeed-apply-status-not-applied"], [data-click-handler="attached"]'
      )
    ).find((el) => isVisibleEnabled(el) && /apply with indeed/i.test(el.innerText || ""));
    if (wrapper) return wrapper;
    for (const el of document.querySelectorAll('button, a[role="button"], [role="button"]')) {
      if (!isVisibleEnabled(el)) continue;
      const text = (el.innerText || el.getAttribute("aria-label") || "").trim();
      if (!text || text.length > 40) continue;
      if (/\bapplied\b/i.test(text)) continue;
      if (/^apply\b|\bapply with indeed\b|\bapply now\b/i.test(text)) return el;
    }
    return null;
  }
  var PACE_MS = 1500;
  var POSITIVE_RE = /\b(review|continue|submit|next|proceed|advance|finish|send)\b/i;
  var NEGATIVE_RE = /\b(back|cancel|withdraw|close|skip|dismiss|report|feedback|help|sign in|sign out|log in|log out|delete|remove|edit|undo)\b/i;
  function isVisibleEnabled(el) {
    const rect = el.getBoundingClientRect();
    const style = window.getComputedStyle(el);
    return rect.width > 0 && rect.height > 0 && style.visibility !== "hidden" && style.display !== "none" && !el.disabled && el.getAttribute("aria-disabled") !== "true";
  }
  function findAdvanceDom() {
    for (const el of document.querySelectorAll('button[data-testid="continue-button"]')) {
      if (isVisibleEnabled(el)) return el;
    }
    let best = null;
    for (const el of document.querySelectorAll('button, [role="button"], a')) {
      if (!isVisibleEnabled(el)) continue;
      const text = (el.innerText || el.getAttribute("aria-label") || "").trim();
      if (!text || text.length >= 80 || NEGATIVE_RE.test(text) || !POSITIVE_RE.test(text)) continue;
      const rect = el.getBoundingClientRect();
      const score = 1e3 + Math.min(rect.width * rect.height, 5e4) / 1e3;
      if (!best || score > best.score) best = { el, score };
    }
    return best?.el ?? null;
  }
  function sleep(ms) {
    return new Promise((r) => setTimeout(r, ms));
  }
})();
